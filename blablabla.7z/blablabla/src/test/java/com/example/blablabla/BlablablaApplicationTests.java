package com.example.blablabla;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlablablaApplicationTests {

    @Test
    void contextLoads() {
    }

}
